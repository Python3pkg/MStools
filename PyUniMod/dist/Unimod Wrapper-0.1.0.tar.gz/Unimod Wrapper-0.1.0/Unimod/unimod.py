import Unimod.Database
import os
__all__=['database']

database=Unimod.Database.Database(file=os.path.join(os.path.dirname(__file__),'unimod.xml'))
